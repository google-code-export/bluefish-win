/* src/config.h.  Generated from config.h.in by configure.  */
/* Bluefish HTML Editor
 * config.h.in - autoconf template
 *
 * Copyright (C) 2002-2006 Olivier Sessink
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/* header files */
#ifndef HAVE_STDLIB_H /* supress warning when jconfig.h is included */
#define HAVE_STDLIB_H 1
#endif /* HAVE_STDLIB_H */

#define HAVE_UNISTD_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_ERRNO_H 1
#define HAVE_STDIO_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_CTYPE_H 1
#define HAVE_GETOPT_H 1
#define HAVE_MATH_H 1
#define HAVE_TIME_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_FCNTL_H 1
/* #undef HAVE_NETDB_H  */
/* #undef HAVE_NETINET_IN_H  */
/* #undef HAVE_SYS_SOCKET_H  */
/* #undef HAVE_ARPA_INET_H  */
#define HAVE_DIRENT_H 1
/* #undef HAVE_SYS_SELECT_H */

#define HAVE_MALLOC_H 1
#define HAVE_NL_TYPES_H 1
/* #undef HAVE_ALLOCA_H */
/* #undef HAVE_SYS_IPC_H */
/* #undef HAVE_SYS_MSG_H */

/* libaspell */
/* #undef HAVE_LIBASPELL */

/* gnome-vfs-2.0 */
#define HAVE_GNOME_VFS 1

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have alloca, as a function or macro.  */
#define HAVE_ALLOCA 1

/* Define if using alloca.c.  */
/* #undef C_ALLOCA */

/* the package name */
#define PACKAGE "bluefish"

/* the package version */
#define VERSION "1.0.7"

/* the current package name and version */
#define CURRENT_VERSION_NAME "bluefish 1.0.7 HTML editor"

#define CONFIGURE_OPTIONS "./configure /local/share/config.site /local/etc/config.site"

/* debugging output */
/* #undef DEBUG */
/* #undef DEVELOPMENT */

/* with splash screen */
/* #undef NOSPLASH */

/* find and grep for open advanced */
#define EXTERNAL_FIND "/bin/find"
#define EXTERNAL_GREP "/bin/grep"

/* i18n */
#define ENABLE_NLS 1

/* highlighting pattern profiling */
/* #undef HL_PROFILING */

/* have atleast gtk-2.2 */
#define HAVE_ATLEAST_GTK_2_2 1

/* have atleast gtk-2.4 */
#define HAVE_ATLEAST_GTK_2_4 1

/* have atleast gnome-vfs-2.2 */
#define HAVE_ATLEAST_GNOMEVFS_2_2 1

/* have atleast gnome-vfs-2.6 */
#define HAVE_ATLEAST_GNOMEVFS_2_6 1

/* have atleast libgnome-2.6 */
#define HAVE_ATLEAST_GNOMEUI_2_6 1

/* #undef PLATFORM_DARWIN */
/* #undef PLATFORM_SOLARIS */

#define HAVE_PCRE_UTF8 1

