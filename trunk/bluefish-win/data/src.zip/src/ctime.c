#include <time.h>
#ifndef _CTIME__
char *ctime(const time_t *clock)
{
		return asctime(localtime(clock));
}

char *ctime_r(const time_t *clock, char *buf)
{
		char *ret;
		
		ret = asctime(localtime(clock));
		if (ret != NULL)
		{
				  strcpy(buf, ret);
				  ret = buf;
		}
		
		return ret;
}
#define _CTIME__
#endif
/* end of ctime.c */
